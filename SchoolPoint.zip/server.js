const express = require('express');
const fs = require('fs');
const bodyParser = require('body-parser');

const app = express();
const PORT = process.env.PORT || 3000;

// Middleware
app.use(bodyParser.json());
app.use(express.static('public'));

// Routes
app.post('/add-homework', (req, res) => {
    const { name, dueDate } = req.body;
    if (!name || !dueDate) {
        res.status(400).send('Missing name or dueDate in request body');
        return;
    }

    fs.readFile('./public/Data/homework.json', 'utf8', (err, data) => {
        if (err) {
            console.error('Error reading homework JSON file:', err);
            res.status(500).send('Internal Server Error');
            return;
        }

        let homeworks = [];
        if (data) {
            try {
                homeworks = JSON.parse(data);
            } catch (error) {
                console.error('Error parsing homework JSON:', error);
                res.status(500).send('Internal Server Error');
                return;
            }
        }

        homeworks.push({ name, dueDate });

        fs.writeFile('./public/Data/homework.json', JSON.stringify(homeworks, null, 2), err => {
            if (err) {
                console.error('Error writing homework JSON file:', err);
                res.status(500).send('Internal Server Error');
                return;
            }

            res.sendStatus(200);
        });
    });
});
//Login
app.post('/login', (req, res) => {
    // Retrieve username and password from request body
    const { username, password } = req.body;

    // Example: Check username and password against a database
    // Replace this with your actual authentication logic
    if (username === 'admin' && password === 'adminpassword') {
        // Example: If authentication is successful, send back user role
        res.json({ role: 'admin' });
    } else if (username === 'teacher' && password === 'teacherpassword') {
        res.json({ role: 'teacher' });
    } else if (username === 'student' && password === 'studentpassword') {
        res.json({ role: 'student' });
    } else {
        // Example: If authentication fails, send back an error status
        res.status(401).json({ error: 'Authentication failed' });
    }
});

// Function to read student data from JSON file
function readStudentsFromFile(callback) {
    fs.readFile('./data/students.json', 'utf8', (err, data) => {
        if (err) {
            console.error('Error reading students JSON file:', err);
            callback([]);
            return;
        }
        let students = [];
        try {
            students = JSON.parse(data);
        } catch (error) {
            console.error('Error parsing students JSON:', error);
        }
        callback(students);
    });
}

// Function to write student data to JSON file
function writeStudentsToFile(students, callback) {
    fs.writeFile('./data/students.json', JSON.stringify(students, null, 2), err => {
        if (err) {
            console.error('Error writing students JSON file:', err);
            callback(err);
            return;
        }
        callback(null);
    });
}

// Route to add points to a student
app.post('/add-points', (req, res) => {
    const { studentId, points } = req.body;
    readStudentsFromFile(students => {
        const student = students.find(student => student.id === studentId);
        if (student) {
            student.points += points;
            writeStudentsToFile(students, err => {
                if (err) {
                    res.status(500).send('Internal Server Error');
                    return;
                }
                res.sendStatus(200); // Send success status
            });
        } else {
            res.status(404).send('Student not found');
        }
    });
});

// Start server
app.listen(PORT, () => {
    console.log(`Server listening on port ${PORT}`);
});
