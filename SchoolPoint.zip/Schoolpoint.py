import os
import subprocess
import tkinter as tk
from tkinter import messagebox

# Function to start the Node.js server
def start_server():
    try:
        subprocess.Popen(['node', 'server.js'])
        status_label.config(text="Server Status: Running", fg="#28a745")
        start_button.config(state="disabled")
        stop_button.config(state="normal")
        restart_button.config(state="normal")
        messagebox.showinfo('Server Started', 'Node.js server started successfully!')
    except Exception as e:
        messagebox.showerror('Error', f'Failed to start server: {e}')

# Function to stop the Node.js server
def stop_server():
    os.system("taskkill /f /im node.exe")
    status_label.config(text="Server Status: Stopped", fg="#dc3545")
    start_button.config(state="normal")
    stop_button.config(state="disabled")
    restart_button.config(state="disabled")
    messagebox.showinfo('Server Stopped', 'Node.js server stopped successfully!')

# Function to restart the Node.js server
def restart_server():
    stop_server()
    start_server()

# Function to create smooth corner effect for labels
def smooth_corners(widget, radius):
    widget.bind("<Configure>", lambda e: widget.config(highlightbackground=widget['bg'], highlightthickness=0, bd=0))

# Load Montserrat font
font_bold = ("Montserrat", 12, "bold")
font_normal = ("Montserrat", 12)

# Create the main window
root = tk.Tk()
root.title('SchoolPoint')
root.geometry("400x300")
root.configure(bg="#f8f9fa")

# Create and add logo label with smooth corners
logo_label = tk.Label(root, text="SchoolPoint", font=("Montserrat", 20, "bold"), bg="#f8f9fa", fg="#007bff")
logo_label.pack(pady=20)
smooth_corners(logo_label, 10)

# Create and add status label with smooth corners
status_label = tk.Label(root, text="Server Status: Stopped", font=font_normal, bg="#f8f9fa", fg="#212529")
status_label.pack(pady=10)
smooth_corners(status_label, 10)

# Create and add buttons to start, stop, and restart the server with smooth corners
start_button = tk.Button(root, text="Start Server", command=start_server, bg="#007bff", fg="#ffffff", font=font_bold, bd=0, padx=10, pady=5)
start_button.pack(pady=5)

stop_button = tk.Button(root, text="Stop Server", command=stop_server, bg="#dc3545", fg="#ffffff", font=font_bold, bd=0, padx=10, pady=5, state="disabled")
stop_button.pack(pady=5)

restart_button = tk.Button(root, text="Restart Server", command=restart_server, bg="#ffc107", fg="#212529", font=font_bold, bd=0, padx=10, pady=5, state="disabled")
restart_button.pack(pady=5)

# Run the Tkinter event loop
root.mainloop()
