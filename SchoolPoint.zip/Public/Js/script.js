document.addEventListener("DOMContentLoaded", function() {
    const loginForm = document.getElementById('login-form');

    // Define an array of user objects with username, password, and rank properties
    const users = [
        { username: 'admin', password: 'admin123', rank: 'admin' },
        { username: 'teacher', password: 'teacher123', rank: 'teacher' },
        { username: 'student', password: 'student123', rank: 'student' }
        // Add more users as needed
    ];

    loginForm.addEventListener('submit', function(event) {
        event.preventDefault();

        const username = document.getElementById('username').value;
        const password = document.getElementById('password').value;

        // Check if the entered username and password match any user in the users array
        const user = users.find(user => user.username === username && user.password === password);

        if (user) {
            // Redirect to the appropriate page based on the user's rank
            redirectToPage(user.rank);
        } else {
            // Display error message or handle invalid credentials
            alert('Invalid username or password');
        }
    });

    // Function to redirect user to the appropriate page based on their rank
    function redirectToPage(rank) {
        const pages = {
            admin: 'admin.html',
            teacher: 'teacher.html',
            student: 'student.html'
            // Add more ranks and corresponding page URLs as needed
        };

        const page = pages[rank];
        if (page) {
            window.location.href = page;
        } else {
            console.error('Page not found for rank:', rank);
        }
    }
});
