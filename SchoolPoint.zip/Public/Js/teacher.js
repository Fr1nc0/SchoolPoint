document.addEventListener("DOMContentLoaded", function() {
    const homeworkForm = document.getElementById('add-homework-form');

    // Event listener for form submission
    homeworkForm.addEventListener('submit', function(event) {
        event.preventDefault();

        const homeworkNameInput = document.getElementById('homework-name');
        const dueDateInput = document.getElementById('due-date');

        const homeworkName = homeworkNameInput.value;
        const dueDate = dueDateInput.value;

        if (homeworkName.trim() === '' || dueDate.trim() === '') {
            alert('Please fill out all fields.');
            return;
        }

        const formData = { name: homeworkName, dueDate: dueDate };

        fetch('/add-homework', {
            method: 'POST',
            headers: {
                'Content-Type': 'application/json'
            },
            body: JSON.stringify(formData)
        })
        .then(response => {
            if (response.ok) {
                alert('Homework added successfully!');
                location.reload()
                homeworkForm.reset();
            } else {
                alert('Failed to add homework.');
            }
        })
        .catch(error => {
            console.error('Error adding homework:', error);
            alert('Failed to add homework.');
        });
    });
});

//Fetch Homework
document.addEventListener("DOMContentLoaded", function() {
    const homeworkList = document.getElementById('homeworks');

    // Function to update homework list
    function updateHomeworkList(homeworkData) {
        homeworkList.innerHTML = ''; // Clear existing list items

        homeworkData.forEach(homework => {
            const li = document.createElement('li');
            li.textContent = `Name: ${homework.name}, Due Date: ${homework.dueDate}`;
            homeworkList.appendChild(li);
        });
    }

    // Function to fetch homework data from JSON file
    function fetchHomeworkData() {
        return fetch('data/homework.json')
            .then(response => {
                if (!response.ok) {
                    throw new Error('Failed to fetch homework data');
                }
                return response.json();
            })
            .catch(error => {
                console.error('Error fetching homework data:', error);
                return [];
            });
    }

    // Fetch homework data and update homework list on page load
    fetchHomeworkData()
        .then(data => updateHomeworkList(data))
        .catch(error => console.error('Error updating homework list:', error));

    // Update homework list every 8 seconds (example)
    setInterval(() => {
        fetchHomeworkData()
            .then(data => updateHomeworkList(data))
            .catch(error => console.error('Error updating homework list:', error));
    }, 8000);
});

// Function to update homework list
function updateHomeworkList(homeworkData) {
    const homeworkList = document.getElementById('homeworks');
    homeworkList.innerHTML = ''; // Clear existing list items

    homeworkData.forEach(homework => {
        const li = document.createElement('li');
        li.textContent = `Name: ${homework.name}, Due Date: ${homework.dueDate}`;
        li.addEventListener('click', () => {
            // Set the selected homework ID
            selectedHomeworkId = homework.id;
            // Populate options for student select
            populateStudentOptions(selectedHomeworkId);
        });
        homeworkList.appendChild(li);
    });
}

// Event listener for homework list item click
document.getElementById('homework-list').addEventListener('click', event => {
    if (event.target.tagName === 'LI') {
        // Add your logic here to handle assignment selection
        // You can access the homework data using event.target.textContent
    }
});

// Function to populate options for student select based on selected assignment
function populateStudentOptions(homeworkId) {
    const studentSelect = document.getElementById('student-select');
    // Fetch student data for the selected assignment from the server
    fetch(`/fetch-students?homeworkId=${homeworkId}`)
        .then(response => response.json())
        .then(data => {
            // Clear previous options
            studentSelect.innerHTML = '';
            data.forEach(student => {
                const option = document.createElement('option');
                option.value = student.id;
                option.textContent = student.name;
                studentSelect.appendChild(option);
            });
        })
        .catch(error => {
            console.error('Error fetching student data:', error);
        });
}
