document.addEventListener("DOMContentLoaded", function() {
    const homeworkForm = document.getElementById('add-homework-form');

    // Event listener for form submission
    homeworkForm.addEventListener('submit', function(event) {
        event.preventDefault();

        const homeworkNameInput = document.getElementById('homework-name');
        const dueDateInput = document.getElementById('due-date');

        const homeworkName = homeworkNameInput.value;
        const dueDate = dueDateInput.value;

        if (homeworkName.trim() === '' || dueDate.trim() === '') {
            alert('Please fill out all fields.');
            return;
        }

        const formData = { name: homeworkName, dueDate: dueDate };

        fetch('/add-homework', {
            method: 'POST',
            headers: {
                'Content-Type': 'application/json'
            },
            body: JSON.stringify(formData)
        })
        .then(response => {
            if (response.ok) {
                alert('Homework added successfully!');
                location.reload()
                homeworkForm.reset();
            } else {
                alert('Failed to add homework.');
            }
        })
        .catch(error => {
            console.error('Error adding homework:', error);
            alert('Failed to add homework.');
        });
    });
});
//Fetch Homework
document.addEventListener("DOMContentLoaded", function() {
    const homeworkList = document.getElementById('homeworks');

    // Function to update homework list
    function updateHomeworkList(homeworkData) {
        homeworkList.innerHTML = ''; // Clear existing list items

        homeworkData.forEach(homework => {
            const li = document.createElement('li');
            li.textContent = `Name: ${homework.name}, Due Date: ${homework.dueDate}`;
            homeworkList.appendChild(li);
        });
    }

    // Function to fetch homework data from JSON file
    function fetchHomeworkData() {
        return fetch('data/homework.json')
            .then(response => {
                if (!response.ok) {
                    throw new Error('Failed to fetch homework data');
                }
                return response.json();
            })
            .catch(error => {
                console.error('Error fetching homework data:', error);
                return [];
            });
    }

    // Fetch homework data and update homework list on page load
    fetchHomeworkData()
        .then(data => updateHomeworkList(data))
        .catch(error => console.error('Error updating homework list:', error));

    // Update homework list every 8 seconds (example)
    setInterval(() => {
        fetchHomeworkData()
            .then(data => updateHomeworkList(data))
            .catch(error => console.error('Error updating homework list:', error));
    }, 8000);
});
